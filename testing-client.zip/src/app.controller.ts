import {
  Controller,
  Get,
  Post,
  Query,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { AppService } from './app.service';
import { GetUploadUrlDto } from './dto/getUploadUrl.dto';
import * as fs from 'fs/promises';
import axios from 'axios';
import { GetAllObjectsDataDto } from './dto/getAllObjectsData.dto';
import { GetOneObjectDataDto } from './dto/getOneObjectsData.dto';
import { ResponceDto } from './dto/responce.dto';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Post('/uploadFile')
  @UseInterceptors(FileInterceptor('file'))
  async uploadFile(
    @UploadedFile() file: Express.Multer.File,
    @Query() query?: GetUploadUrlDto,
  ) {
    const fileBuffer = await fs.readFile(file.path);

    const urlRequest: ResponceDto = await this.appService.getUploadUrl({
      fileType: file.mimetype,
      originalname: file.originalname,
      ...query,
    });

    if (urlRequest.status === 200) {
      const url = urlRequest.message;

      const axiosResponse = await axios.put(url, fileBuffer, {
        headers: {
          'Content-Type': file.mimetype,
        },
      });

      return axiosResponse.data;
    }

    return urlRequest;
  }

  @Get('allObjects')
  async getAllObjects(@Query() query: GetAllObjectsDataDto) {
    return this.appService.getAllObjects(query);
  }

  @Get('oneObject')
  async getOneObject(@Query() query: GetOneObjectDataDto) {
    return this.appService.getOneObjectDataByKey(query);
  }
}
