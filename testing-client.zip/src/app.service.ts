import { Inject, Injectable } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { GetUploadUrlDto } from './dto/getUploadUrl.dto';
import { lastValueFrom } from 'rxjs';
import { GetAllObjectsDataDto } from './dto/getAllObjectsData.dto';
import { GetOneObjectDataDto } from './dto/getOneObjectsData.dto';

@Injectable()
export class AppService {
  constructor(@Inject('S3_SERVICE') private client: ClientProxy) {}

  async getUploadUrl(query?: GetUploadUrlDto) {
    return lastValueFrom(this.client.send({ cmd: 'getPutObjectUrl' }, query));
  }

  async getAllObjects(query?: GetAllObjectsDataDto) {
    return lastValueFrom(this.client.send({ cmd: 'getAllObjectsData' }, query));
  }

  async getOneObjectDataByKey(query?: GetOneObjectDataDto) {
    return lastValueFrom(this.client.send({ cmd: 'getOneObjectData' }, query));
  }
}
