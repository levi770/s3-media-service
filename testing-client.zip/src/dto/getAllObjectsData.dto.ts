export class GetAllObjectsDataDto {
  page?: string;
  limit?: string;
  order?: string;
  order_by?: string;
  include_child?: string;
}
