export class ResponceDto {
  status: number;
  message: string;
}
