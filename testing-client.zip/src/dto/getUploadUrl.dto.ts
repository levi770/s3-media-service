export class GetUploadUrlDto {
  fileType: string;
  originalname: string;
  optimize?: string;
  resize?: string;
  size?: string;
  quality?: string;
}
