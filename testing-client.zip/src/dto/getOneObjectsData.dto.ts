export class GetOneObjectDataDto {
  id?: string;
  key?: string;
  include_child?: string;
}
